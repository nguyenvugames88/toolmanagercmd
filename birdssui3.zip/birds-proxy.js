const fs = require('fs');
const path = require('path');
const axios = require('axios');
const colors = require('colors');
const readline = require('readline');
const { DateTime } = require('luxon');
const { HttpsProxyAgent } = require('https-proxy-agent');

class BirdX {
    constructor() {
        this.headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
            "Content-Type": "application/json",
            "Origin": "https://birdx.birds.dog",
            "Referer": "https://birdx.birds.dog/",
            "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Google Chrome";v="115", "Chromium";v="115"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
        };
        this.proxyList = this.loadProxies();
    }

    loadProxies() {
        const proxyFile = path.join(__dirname, 'proxy.txt');
        return fs.readFileSync(proxyFile, 'utf8')
            .replace(/\r/g, '')
            .split('\n')
            .filter(Boolean);
    }

    async checkProxyIP(index,proxy) {
        try {
            const proxyAgent = new HttpsProxyAgent(proxy);
            const response = await axios.get('https://api.ipify.org?format=json', { httpsAgent: proxyAgent });
            if (response.status === 200) {
                return response.data.ip;
            } else {
                throw new Error(index,`Không thể kiểm tra IP của proxy. Status code: ${response.status}`);
            }
        } catch (error) {
            throw new Error(index,`Error khi kiểm tra IP của proxy: ${error.message}`);
        }
    }

    log(index,msg, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        switch(type) {
            case 'success':
                console.log(`[${timestamp}] [TK ${index}] [*] ${msg}`.green);
                break;
            case 'custom':
                console.log(`[${timestamp}] [TK ${index}] [*] ${msg}`.magenta);
                break;        
            case 'error':
                console.log(`[${timestamp}] [TK ${index}] [!] ${msg}`.red);
                break;
            case 'warning':
                console.log(`[${timestamp}] [TK ${index}] [*] ${msg}`.yellow);
                break;
            default:
                console.log(`[${timestamp}] [TK ${index}] [*] ${msg}`.blue);
        }
    }

    async countdown(seconds) {
        try{
            for (let i = seconds; i >= 0; i--) {
                readline.cursorTo(process.stdout, 0);
                process.stdout.write(`Chờ ${i} giây để tiếp tục...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            this.log('','', 'info');
        } catch{
            throw new Error("Lỗi không xác định!");
        }
    }

    async callAPI(index,telegramauth, proxy) {
        const url = "https://api.birds.dog/user";
        const headers = { 
            ...this.headers, 
            "Telegramauth": `tma ${telegramauth}`
        };
        const payload = {
            "name": JSON.parse(decodeURIComponent(telegramauth.split('user=')[1].split('&')[0])).first_name + " " + JSON.parse(decodeURIComponent(telegramauth.split('user=')[1].split('&')[0])).last_name,
            "referId": 376905749,
            "username": JSON.parse(decodeURIComponent(telegramauth.split('user=')[1].split('&')[0])).username
        };

        const proxyAgent = new HttpsProxyAgent(proxy);

        try {
            const getResponse = await axios.get(url, { headers, httpsAgent: proxyAgent });
            if (getResponse.data && getResponse.data.balance !== undefined) {
                this.log(index,`Đăng nhập thành công!`, 'success');
                this.log(index,`Balance: ${getResponse.data.balance}`, 'custom');
                return getResponse.data;
            } else {
                throw new Error("Tài khoản mới");
            }
        } catch (error) {
            this.log(index,`Đăng nhập không thành công, đăng kí tài khoản...`, 'warning');
            
            try {
                const postResponse = await axios.post(url, payload, { headers, httpsAgent: proxyAgent });
                if (postResponse.data && postResponse.data.balance !== undefined) {
                    this.log(index,`Đăng ký thành công!`, 'success');
                    this.log(index,`Balance: ${postResponse.data.balance}`, 'custom');
                    return postResponse.data;
                } else {
                    throw new Error("Không thể đăng kí tài khoản");
                }
            } catch (postError) {
                this.log(index,`Lỗi rồi: ${postError.message}`, 'error');
            }
        }

        this.log(index,"Đăng nhập thất bại. chuyển tài khoản", 'error');
        return null;
    }

    async callWormMintAPI(index,telegramauth, proxy) {
        const statusUrl = "https://worm.birds.dog/worms/mint-status";
        const mintUrl = "https://worm.birds.dog/worms/mint";
        const headers = { 
            ...this.headers, 
            "Authorization": `tma ${telegramauth}`
        };
        const proxyAgent = new HttpsProxyAgent(proxy);

        try {
            const statusResponse = await axios.get(statusUrl, { headers, httpsAgent: proxyAgent });
            const statusData = statusResponse.data.data;

            if (statusData.status === "MINT_OPEN") {
                this.log(index,"Nhìn thấy sâu, bắt nó...", 'info');
                
                const mintResponse = await axios.post(mintUrl, {}, { headers, httpsAgent: proxyAgent });
                const mintData = mintResponse.data.data;
                this.log(index,`Kết quả: ${mintResponse.data.message}`, 'custom');
                
                if (mintData && mintData.status === "WAITING") {
                    const nextMintTime = DateTime.fromISO(mintData.nextMintTime);
                    const formattedNextMintTime = nextMintTime.toLocaleString(DateTime.DATETIME_FULL);
                    this.log(index,`Lần bắt sâu tiếp theo: ${formattedNextMintTime}`, 'info');
                }
            } else if (statusData.status === "WAITING") {
                const nextMintTime = DateTime.fromISO(statusData.nextMintTime);
                const formattedNextMintTime = nextMintTime.toLocaleString(DateTime.DATETIME_FULL);
                this.log(index,`Không thấy con sâu nào, lần bắt tiếp theo: ${formattedNextMintTime}`, 'warning');
            } else {
                this.log(index,`Trạng thái: ${statusData.status}`, 'warning');
            }
        } catch (error) {
            this.log(index,`Lỗi rồi: ${error.message}`, 'error');
        }
    }

    async playEggMinigame(index,telegramauth, proxy) {
        const headers = { 
            ...this.headers, 
            "Telegramauth": `tma ${telegramauth}`
        };
        const proxyAgent = new HttpsProxyAgent(proxy);

        try {
            const joinResponse = await axios.get("https://api.birds.dog/minigame/egg/join", { headers, httpsAgent: proxyAgent });
            let { turn } = joinResponse.data;
            this.log(index,`Bắt đầu đập trứng: có ${turn} lượt`, 'info');

            const turnResponse = await axios.get("https://api.birds.dog/minigame/egg/turn", { headers, httpsAgent: proxyAgent });
            turn = turnResponse.data.turn;
            this.log(index,`Lượt hiện tại: ${turn}`, 'info');

            let totalReward = 0;

            while (turn > 0) {
                const playResponse = await axios.get("https://api.birds.dog/minigame/egg/play", { headers, httpsAgent: proxyAgent });
                const { result } = playResponse.data;
                turn = playResponse.data.turn;
                totalReward += result;
                this.log(index,`Còn ${turn} lần đập trứng | Phần thưởng ${result}`, 'custom');
            }

            const claimResponse = await axios.get("https://api.birds.dog/minigame/egg/claim", { headers, httpsAgent: proxyAgent });
            if (claimResponse.data === true) {
                this.log(index,"Claim thành công!", 'success');
                this.log(index,`Tổng phần thưởng: ${totalReward}`, 'custom');
            } else {
                this.log(index,"Claim thất bại", 'error');
            }
        } catch (error) {
            this.log(index,`Egg minigame error: ${error.message}`, 'error');
        }
    }

    async nangcap(index,telegramauth, balance, proxy) {
        const headers = { 
            ...this.headers, 
            "Telegramauth": `tma ${telegramauth}`
        };
        const proxyAgent = new HttpsProxyAgent(proxy);
    
        try {
            const infoResponse = await axios.get("https://api.birds.dog/minigame/incubate/info", { headers, httpsAgent: proxyAgent });
            let incubationInfo = infoResponse.data;
            this.log(index,`Cấp độ của trứng: ${incubationInfo.level}`, 'info');
    
            const currentTime = Date.now();
            const upgradeCompletionTime = incubationInfo.upgradedAt + (incubationInfo.duration * 60 * 60 * 1000);
    
            if (incubationInfo.status === "processing") {
                if (currentTime > upgradeCompletionTime) {
                    const confirmResponse = await axios.post("https://api.birds.dog/minigame/incubate/confirm-upgraded", {}, { headers, httpsAgent: proxyAgent });
                    if (confirmResponse.data === true) {
                        this.log(index,"Hoàn thành nâng cấp", 'success');
                        const updatedInfoResponse = await axios.get("https://api.birds.dog/minigame/incubate/info", { headers, httpsAgent: proxyAgent });
                        incubationInfo = updatedInfoResponse.data;
                    } else {
                        this.log(index,"Xác nhận nâng cấp thất bại", 'error');
                    }
                } else {
                    const remainingTime = Math.ceil((upgradeCompletionTime - currentTime) / (60 * 1000));
                    this.log(index,`Đang trong quá trình nâng cấp. Thời gian còn lại: ${remainingTime} phút`, 'info');
                    return;
                }
            }
    
            if (incubationInfo.status === "confirmed" && incubationInfo.nextLevel) {
                if (balance >= incubationInfo.nextLevel.birds) {
                    await this.upgradeEgg(headers, proxyAgent);
                } else {
                    this.log(index,`Không đủ birds để nâng cấp. Cần ${incubationInfo.nextLevel.birds} birds`, 'warning');
                }
            } else if (incubationInfo.status === "confirmed") {
                this.log(index,"Đã đạt cấp độ tối đa", 'info');
            }
        } catch (error) {
            if (error.response && error.response.status === 400 && error.response.data === 'Start incubating your egg now') {
                this.log(index,"Bắt đầu ấp trứng ngay bây giờ.", 'warning');
                await this.upgradeEgg(headers, proxyAgent);
            } else {
                this.log(index,`Lỗi nâng cấp trứng: ${error.message}`, 'error');
            }
        }
    }
    
    async upgradeEgg(index,headers, proxyAgent) {
        try {
            const upgradeResponse = await axios.get("https://api.birds.dog/minigame/incubate/upgrade", { headers, httpsAgent: proxyAgent });
            const upgradeInfo = upgradeResponse.data;
            const upgradeCompletionTime = upgradeInfo.upgradedAt + (upgradeInfo.duration * 60 * 60 * 1000);
            const completionDateTime = new Date(upgradeCompletionTime);
            this.log(index,`Bắt đầu nâng cấp lên level ${upgradeInfo.level}. Hoàn thành lúc: ${completionDateTime.toLocaleString()}`, 'success');
        } catch (error) {
            this.log(index,`Lỗi khi nâng cấp trứng: ${error.message}`, 'error');
        }
    }

    async performTasks(index,telegramauth, proxy) {
        const headers = { 
            ...this.headers, 
            "Telegramauth": `tma ${telegramauth}`
        };
        const proxyAgent = new HttpsProxyAgent(proxy);

        try {
            const projectResponse = await axios.get("https://api.birds.dog/project", { headers, httpsAgent: proxyAgent });
            const allTasks = projectResponse.data.flatMap(project => project.tasks);
            
            const userTasksResponse = await axios.get("https://api.birds.dog/user-join-task", { headers, httpsAgent: proxyAgent });
            const completedTaskIds = userTasksResponse.data.map(task => task.taskId);

            const incompleteTasks = allTasks.filter(task => !completedTaskIds.includes(task._id));

            for (const task of incompleteTasks) {
                try {
                    const payload = {
                        taskId: task._id,
                        channelId: task.channelId || "",
                        'cf-turnstile-response': task.slug || "",
                        //point: task.point
                    };

                    const joinTaskResponse = await axios.post("https://api.birds.dog/project/join-task", payload, { headers, httpsAgent: proxyAgent });
                    
                    if (joinTaskResponse.data.msg === "Successfully") {
                        this.log(index,`Làm nhiệm vụ ${task.title} thành công | phần thưởng: ${task.point}`, 'success');
                    } else {
                        this.log(index,`Làm nhiệm vụ ${task.title} thất bại`, 'error');
                    }
                } catch (error) {
                    this.log(index,`Lỗi khi thực hiện nhiệm vụ ${task.title}: ${error.message}`, 'error');
                }

                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            if (incompleteTasks.length === 0) {
                this.log(index,"Tất cả nhiệm vụ đã hoàn thành", 'info');
            }
        } catch (error) {
            this.log(index,`Lỗi khi thực hiện các nhiệm vụ: ${error.message}`, 'error');
        }
    }

    askQuestion(query) {
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });
        return new Promise(resolve => rl.question(query, ans => {
            rl.close();
            resolve(ans);
        }))
    }

    async checkAndJoinGuild(index,telegramauth, proxy) {
        const headers = { 
            ...this.headers, 
            "Telegramauth": `tma ${telegramauth}`
        };
        const proxyAgent = new HttpsProxyAgent(proxy);
        
        try {
            const guildStatusResponse = await axios.get("https://api.birds.dog/guild/me", { 
                headers, 
                httpsAgent: proxyAgent 
            });
            
            if (guildStatusResponse.data === null) {
                try {
                    const joinResponse = await axios.get("https://api.birds.dog/guild/join/671b0b55098679d7ffb97a70", {
                        headers,
                        httpsAgent: proxyAgent
                    });
                    
                    if (joinResponse.data === "ok") {
                        this.log(index,"Gia nhập thành công guild Dân Cày Airdrop", 'success');
                    }
                } catch (joinError) {
                    this.log(index,`Không thể gia nhập guild: ${joinError.message}`, 'error');
                }
            } else {
                const guildData = guildStatusResponse.data;
                if (guildData.guild._id === "671b0b55098679d7ffb97a70") {
                    this.log(index,"Bạn đã gia nhập guild Dân Cày Airdrop", 'info');
                    this.log(index,`Số Bird trong guild: ${guildData.guild.bird}`, 'custom');
                    this.log(index,`Bird có thể claim: ${guildData.guild.claimable}`, 'custom');
                } else {
                    this.log(index,`Bạn đang ở trong guild khác: ${guildData.guild.name}`, 'warning');
                }
            }
        } catch (error) {
            this.log(index,`Lỗi kiểm tra guild: ${error.message}`, 'error');
        }
    }

    async main() {
        const dataFile = path.join(__dirname, 'data.txt');
        const data = fs.readFileSync(dataFile, 'utf8')
            .replace(/\r/g, '')
            .split('\n')
            .filter(Boolean);
        this.log(`Tool được chia sẻ tại kênh telegram Automation Genlogin Paul Kevin (https://t.me/AutomationPaulKevin)`.green);
        
        const nangcapt = await this.askQuestion('Bạn có muốn nâng cấp không? (y/n): ');
        const hoinangcapt = nangcapt.toLowerCase() === 'y';
    
        const nhiemvu = await this.askQuestion('Bạn có muốn làm nhiệm vụ không? (y/n): ');
        const hoinhiemvu = nhiemvu.toLowerCase() === 'y';
    
        const numThreads = parseInt(await this.askQuestion('Nhập số luồng (threads) muốn sử dụng: '), 10);
        while (true){
            // Function to process each account's data
            const processAccount = async (i) => {
                const telegramauth = data[i];
                const userData = JSON.parse(decodeURIComponent(telegramauth.split('user=')[1].split('&')[0]));
                const userId = userData.id;
                const firstName = userData.first_name;
                const proxy = this.proxyList[i % this.proxyList.length];
        
                let proxyIP = 'Unknown';
                try {
                    proxyIP = await this.checkProxyIP(i + 1,proxy);
                } catch (error) {
                    this.log(i + 1,`Không thể kiểm tra IP của proxy: ${error.message}`, 'warning');
                    return;
                }
        
                //console.log(`========== Tài khoản ${i + 1} | ${firstName.green} | ip: ${proxyIP} ==========`);
        
                const apiResult = await this.callAPI(i + 1,telegramauth, proxy);
                if (apiResult) {
                    const balance = apiResult.balance;
                    await this.checkAndJoinGuild(i + 1,telegramauth, proxy);
                    await this.callWormMintAPI(i + 1,telegramauth, proxy);
                    await this.playEggMinigame(i + 1,telegramauth, proxy);
                    if (hoinangcapt) {
                        this.log(i + 1,`Bắt đầu kiểm tra và nâng cấp trứng...`, 'info');
                        await this.nangcap(i + 1,telegramauth, balance, proxy);
                    }
                    if (hoinhiemvu) {
                        this.log(i + 1,`Bắt đầu thực hiện các nhiệm vụ...`, 'info');
                        await this.performTasks(i + 1,telegramauth, proxy);
                    }
                } else {
                    this.log(i + 1,`API call thất bại cho tài khoản ${userId}. Bỏ qua tài khoản này.`, 'error');
                }
        
                await new Promise(resolve => setTimeout(resolve, 1000)); // Add a delay between tasks
            };
        
            // Start processing accounts in parallel based on user input
            let threadCount = 0;
            const promises = [];
            for (let i = 0; i < data.length; i++) {
                if (threadCount >= numThreads) {
                    await Promise.race(promises); // Wait for the first promise to resolve
                    threadCount--; // Reduce thread count once one task finishes
                }
                // Add a new promise to the array and increase thread count
                const promise = processAccount(i).finally(() => {
                    threadCount--;
                });
                promises.push(promise);
                threadCount++;
            }
        
            // Wait for all remaining tasks to complete
            await Promise.all(promises);
        
            try {
                await this.countdown( 60*60); // Wait for 1 hour before restarting the loop
            } catch (error) {
                console.error("Countdown failed:", error);
            }
        }
        
    }
    
}

const client = new BirdX();
client.main().catch(err => {
    client.log(err.message, 'error');
    process.exit(1);
});