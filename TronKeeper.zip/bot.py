import requests
import json
import os
from colorama import *
from datetime import datetime
import time
import pytz
import asyncio


wib = pytz.timezone('Asia/Jakarta')

class TronKeeper:
    def __init__(self) -> None:
        self.session = requests.Session()
        self.headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Cache-Control': 'no-cache',
            'Host': 'bot-api.tronkeeper.app',
            'Origin': 'https://bot.tronkeeper.app',
            'Pragma': 'no-cache',
            'Referer': 'https://bot.tronkeeper.app/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'
        }

    def clear_terminal(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def log(self, message):
        print(
            f"{Fore.CYAN + Style.BRIGHT}[ {datetime.now().astimezone(wib).strftime('%x %X %Z')} ]{Style.RESET_ALL}"
            f"{Fore.WHITE + Style.BRIGHT} | {Style.RESET_ALL}{message}",
            flush=True
        )

    def welcome(self):
        print(
            f"""
        {Fore.GREEN + Style.BRIGHT}Auto Claim {Fore.BLUE + Style.BRIGHT}TronKeeper - BOT by AutomationKevin (https://t.me/AutomationPaulKevin)
            """
        )

    def format_seconds(self, seconds):
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{int(hours):02}:{int(minutes):02}:{int(seconds):02}"

    def user_login(self, query: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/bot/auth'
        data = json.dumps({"data":query})
        self.headers.update({
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.post(url, headers=self.headers, data=data, timeout=10)
                response.raise_for_status()
                return response.json()['data']['token']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None

    def user_profile(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/bot/profile'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None

    def user_verify(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/bot/verify'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def hold_usdt(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/daily/hold'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def check_ton(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/ton/check-hold'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']['ton']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def hold_ton(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/ton/hold'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def check_tonarx(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/tonarx/check-hold'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def hold_tonarx(self, token: str, retries=3):
        url = 'https://bot-api.tronkeeper.app/tonarx/hold'
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.get(url, headers=self.headers, timeout=10)
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None
        
    def complete_tasks(self, token: str, task_id: int, retries=3):
        url = 'https://bot-api.tronkeeper.app/bot/tasks'
        data = json.dumps({'id':task_id, 'code':''})
        self.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })
        for attempt in range(retries):
            try:
                response = self.session.post(url, headers=self.headers, data=data, timeout=10)
                if response.status_code == 500:
                    return None
                
                response.raise_for_status()
                return response.json()['data']
            except (requests.RequestException, requests.Timeout, ValueError) as e:
                if attempt < retries - 1:
                    print(
                        f"{Fore.RED+Style.BRIGHT}HTTP ERROR{Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT} Retrying... {Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT}[{attempt+1}/{retries}]{Style.RESET_ALL}",
                        end="\r",
                        flush=True
                    )
                    time.sleep(2)
                else:
                    return None

    async def process_query(self, query: str):
        token = self.user_login(query)
        if not token:
            self.log(
                f"{Fore.MAGENTA+Style.BRIGHT}[ Account{Style.RESET_ALL}"
                f"{Fore.RED+Style.BRIGHT} Query May Expired {Style.RESET_ALL}"
                f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
            )
            return
        
        if token:
            user = self.user_profile(token)
            wallet = user.get('wallet') if user else None
            if not wallet:
                verify = self.user_verify(token)
                if not verify:
                    self.log(
                        f"{Fore.MAGENTA+Style.BRIGHT}[ Account{Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT} {user['user']['fullName']} {Style.RESET_ALL}"
                        f"{Fore.RED+Style.BRIGHT}Isn't Verified{Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT} ] [ Reason{Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT} Subscribe Tron Keeper Channel First {Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                    )
                    return
                
                wallet = verify.get('wallet')

                if wallet:
                    user = self.user_profile(token)

            if wallet and user:
                usdt = wallet.get('USDT', {}).get('balance', 0)
                tonarx = wallet.get('TONARX', {}).get('balance', 0)
                self.log(
                    f"{Fore.MAGENTA+Style.BRIGHT}[ Account{Style.RESET_ALL}"
                    f"{Fore.WHITE+Style.BRIGHT} {user['user']['fullName']} {Style.RESET_ALL}"
                    f"{Fore.MAGENTA+Style.BRIGHT}] [ Balance{Style.RESET_ALL}"
                    f"{Fore.WHITE+Style.BRIGHT} {usdt} $USDT {Style.RESET_ALL}"
                    f"{Fore.MAGENTA+Style.BRIGHT}-{Style.RESET_ALL}"
                    f"{Fore.WHITE+Style.BRIGHT} {tonarx} $TONARX {Style.RESET_ALL}"
                    f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                )
                await asyncio.sleep(1)

                hold_count = user['hold']
                if hold_count > 0:
                    while hold_count > 0:
                        hold = self.hold_usdt(token)
                        if hold:
                            hold_count = hold['limit']
                            self.log(
                                f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                                f"{Fore.WHITE+Style.BRIGHT} USDT {Style.RESET_ALL}"
                                f"{Fore.GREEN+Style.BRIGHT}Is Success{Style.RESET_ALL}"
                                f"{Fore.MAGENTA+Style.BRIGHT} ] [ Reward{Style.RESET_ALL}"
                                f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['USDT']} $USDT {Style.RESET_ALL}"
                                f"{Fore.MAGENTA+Style.BRIGHT}] [ Chance{Style.RESET_ALL}"
                                f"{Fore.WHITE+Style.BRIGHT} {hold_count} Left {Style.RESET_ALL}"
                                f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                            )
                        else:
                            break

                        await asyncio.sleep(1)

                    if hold_count == 0:
                        self.log(
                            f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                            f"{Fore.WHITE+Style.BRIGHT} USDT {Style.RESET_ALL}"
                            f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                            f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                        )
                else:
                    self.log(
                        f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT} USDT {Style.RESET_ALL}"
                        f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                    )
                await asyncio.sleep(1)

                ton = self.check_ton(token)
                if ton:
                    hold_count = ton['count']
                    if hold_count > 0:
                        while hold_count > 0:
                            hold = self.hold_ton(token)
                            if hold:
                                hold_count = hold['ton']['count']
                                self.log(
                                    f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} TON {Style.RESET_ALL}"
                                    f"{Fore.GREEN+Style.BRIGHT}Is Success{Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT} ] [ Chance{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold_count} Left {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                                )
                                self.log(
                                    f"{Fore.MAGENTA+Style.BRIGHT}[ Reward{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['Blum']} $BLUM {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}-{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['Paws']} $PAWS {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}-{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['Major']} $MAJOR {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}-{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['Moonbix']} $MOONBIX {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}-{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['NotPixel']} $NPX {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                                )
                            else:
                                break

                            await asyncio.sleep(1)

                        if hold_count == 0:
                            self.log(
                                f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                                f"{Fore.WHITE+Style.BRIGHT} TON {Style.RESET_ALL}"
                                f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                                f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                            )
                    else:
                        self.log(
                            f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                            f"{Fore.WHITE+Style.BRIGHT} TON {Style.RESET_ALL}"
                            f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                            f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                        )
                else:
                    self.log(
                        f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT} TON {Style.RESET_ALL}"
                        f"{Fore.RED+Style.BRIGHT}Data Is None{Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                    )
                await asyncio.sleep(1)

                tonarx = self.check_tonarx(token)
                if tonarx:
                    hold_count = tonarx['limit']
                    if hold_count > 0:
                        while hold_count > 0:
                            hold = self.hold_tonarx(token)
                            if hold:
                                hold_count = hold['limit']
                                self.log(
                                    f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} TONARX {Style.RESET_ALL}"
                                    f"{Fore.GREEN+Style.BRIGHT}Is Success{Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT} ] [ Reward{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold['prize']['TONARX']} $TONARX {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}] [ Chance{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {hold_count} Left {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                                )
                            else:
                                break

                            await asyncio.sleep(1)

                        if hold_count == 0:
                            self.log(
                                f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                                f"{Fore.WHITE+Style.BRIGHT} TONARX {Style.RESET_ALL}"
                                f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                                f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                            )
                    else:
                        self.log(
                            f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                            f"{Fore.WHITE+Style.BRIGHT} TONARX {Style.RESET_ALL}"
                            f"{Fore.YELLOW+Style.BRIGHT}No Avaialable Chance{Style.RESET_ALL}"
                            f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                        )
                else:
                    self.log(
                        f"{Fore.MAGENTA+Style.BRIGHT}[ Hold{Style.RESET_ALL}"
                        f"{Fore.WHITE+Style.BRIGHT} TONARX {Style.RESET_ALL}"
                        f"{Fore.RED+Style.BRIGHT}Data Is None{Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                    )
                await asyncio.sleep(1)

                tasks = user['tasks']
                user_task_ids = user['userTask']
                if tasks:
                    pending_tasks = [
                        task for task in tasks if task['id'] not in user_task_ids
                    ]

                    for task in pending_tasks:
                        task_id = task['id']

                        if task:
                            complete = self.complete_tasks(token, task_id)
                            if complete:
                                self.log(
                                    f"{Fore.MAGENTA+Style.BRIGHT}[ Task{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {task['title']} {Style.RESET_ALL}"
                                    f"{Fore.GREEN+Style.BRIGHT}Is Completed{Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT} ] [ Reward{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {task['reward']['USDT']} $USDT {Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                                )
                            else:
                                self.log(
                                    f"{Fore.MAGENTA+Style.BRIGHT}[ Task{Style.RESET_ALL}"
                                    f"{Fore.WHITE+Style.BRIGHT} {task['title']} {Style.RESET_ALL}"
                                    f"{Fore.RED+Style.BRIGHT}Isn't Completed{Style.RESET_ALL}"
                                    f"{Fore.MAGENTA+Style.BRIGHT} ]{Style.RESET_ALL}"
                                )
                            await asyncio.sleep(1)
                    else:
                        self.log(
                            f"{Fore.MAGENTA+Style.BRIGHT}[ Task{Style.RESET_ALL}"
                            f"{Fore.GREEN+Style.BRIGHT} Is Completed {Style.RESET_ALL}"
                            f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                        )
                else:
                    self.log(
                        f"{Fore.MAGENTA+Style.BRIGHT}[ Task{Style.RESET_ALL}"
                        f"{Fore.RED+Style.BRIGHT} Data Is None {Style.RESET_ALL}"
                        f"{Fore.MAGENTA+Style.BRIGHT}]{Style.RESET_ALL}"
                    )
            
    async def main(self):
        try:
            # Đọc dữ liệu từ file
            with open('data.txt', 'r') as file:
                queries = [line.strip() for line in file if line.strip()]

            while True:
                self.clear_terminal()
                await asyncio.sleep(1)
                self.welcome()
                self.log(
                    f"{Fore.GREEN + Style.BRIGHT}Account's Total: {Style.RESET_ALL}"
                    f"{Fore.WHITE + Style.BRIGHT}{len(queries)}{Style.RESET_ALL}"
                )
                self.log(f"{Fore.CYAN + Style.BRIGHT}-{Style.RESET_ALL}" * 75)

                # Vòng lặp xử lý từng query
                for query in queries:
                    query = query.strip()
                    if query:
                        try:
                            await self.process_query(query)  # Sử dụng await cho coroutine
                        except Exception as e:
                            self.log(
                                f"{Fore.RED + Style.BRIGHT}[ERROR]{Style.RESET_ALL} "
                                f"Failed to process query: {query}. Error: {e}"
                            )
                        finally:
                            self.log(f"{Fore.CYAN + Style.BRIGHT}-{Style.RESET_ALL}" * 75)
                            await asyncio.sleep(3)  # Thay time.sleep bằng asyncio.sleep

                # Thời gian chờ 30 phút (1800 giây)
                seconds = 1800
                while seconds > 0:
                    formatted_time = self.format_seconds(seconds)
                    print(
                        f"{Fore.CYAN + Style.BRIGHT}[ Wait for{Style.RESET_ALL}"
                        f"{Fore.WHITE + Style.BRIGHT} {formatted_time} {Style.RESET_ALL}"
                        f"{Fore.CYAN + Style.BRIGHT}... ]{Style.RESET_ALL}",
                        end="\r"
                    )
                    await asyncio.sleep(1)  # Không khóa event loop
                    seconds -= 1

        except KeyboardInterrupt:
            self.log(f"{Fore.RED + Style.BRIGHT}[ EXIT ] Midas RWA - BOT.{Style.RESET_ALL}")
        except Exception as e:
            self.log(f"{Fore.RED + Style.BRIGHT}An error occurred: {e}{Style.RESET_ALL}")


if __name__ == "__main__":
    bot = TronKeeper()
    asyncio.run(bot.main())