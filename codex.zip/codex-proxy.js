const fs = require('fs');
const path = require('path');
const axios = require('axios');
const colors = require('colors');
const readline = require('readline');
const { HttpsProxyAgent } = require('https-proxy-agent');

class Codex {
    constructor() {
        this.headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json",
            "Origin": "https://wallet.codexfield.com",
            "Referer": "https://wallet.codexfield.com/",
            "Sec-Ch-Ua": '"Not/A)Brand";v="8", "Chromium";v="129"',
            "Sec-Ch-Ua-Mobile": "?1",
            "Sec-Ch-Ua-Platform": '"Android"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "User-Agent": "Mozilla/5.0 (Linux; Android 11; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36"
        };
        this.proxies = this.loadProxies();
        this.threadCount = 5;
    }

    loadProxies() {
        const proxyFile = path.join(__dirname, 'proxy.txt');
        return fs.readFileSync(proxyFile, 'utf8')
            .replace(/\r/g, '')
            .split('\n')
            .filter(Boolean);
    }

    log(msg, type = 'info',index) {
        const timestamp = new Date().toLocaleTimeString();
        switch(type) {
            case 'success':
                if (index == undefined)
                {
                    console.log(`[${timestamp}] ${msg}`.green );
                    break;
                }else{
                    console.log(`[${timestamp}] [TK số ${index}] [✓] ${msg}`.green );
                    break;                    
                }
            case 'custom':
                if (index == undefined)
                {
                    console.log(`[${timestamp}] ${msg}`.magenta );
                    break;
                }else{
                    console.log(`[${timestamp}] [TK số ${index}] [✓] ${msg}`.magenta );
                    break;                    
                }
            case 'error':
                if (index == undefined)
                {
                    console.log(`[${timestamp}] ${msg}`.red );
                    break;
                }else{
                    console.log(`[${timestamp}] [TK số ${index}] [✓] ${msg}`.red );
                    break;                    
                }
            case 'warning':
                if (index == undefined)
            {
                console.log(`[${timestamp}] ${msg}`.yellow );
                break;
            }else{
                console.log(`[${timestamp}] [TK số ${index}] [✓] ${msg}`.yellow );
                break;                    
            }
            default:
                if (index == undefined)
                {
                    console.log(`[${timestamp}] ${msg}`.blue );
                    break;
                }else{
                    console.log(`[${timestamp}] [TK số ${index}] [✓] ${msg}`.blue );
                    break;                    
                }
        }
    }

    async countdown(seconds) {
        for (let i = seconds; i > 0; i--) {
            const timestamp = new Date().toLocaleTimeString();
            readline.cursorTo(process.stdout, 0);  // Di chuyển con trỏ về đầu dòng
            readline.clearLine(process.stdout, 0); // Xóa toàn bộ dòng hiện tại
            process.stdout.write(`[*] Chờ ${i} giây để tiếp tục...`);  // Hiển thị lại dòng mới
    
            await new Promise(resolve => setTimeout(resolve, 1000));  // Chờ 1 giây
        }
        readline.cursorTo(process.stdout, 0); // Di chuyển con trỏ về đầu dòng
        readline.clearLine(process.stdout, 0); // Xóa dòng cuối cùng khi đếm ngược xong
    }

    async checkProxyIP(proxy) {
        try {
            const proxyAgent = new HttpsProxyAgent(proxy);
            const response = await axios.get('https://api.ipify.org?format=json', { httpsAgent: proxyAgent });
            if (response.status === 200) {
                return response.data.ip;
            } else {
                throw new Error(`Không thể kiểm tra IP của proxy. Status code: ${response.status}`);
            }
        } catch (error) {
            throw new Error(`Error khi kiểm tra IP của proxy: ${error.message}`);
        }
    }

    async login(initDataRaw, proxyAgent,index) {
        const url = "https://api.codexfield.com/api/1/user/login";
        const payload = {
            initDataRaw: initDataRaw,
            randPoint: 180
        };

        try {
            const response = await axios.post(url, payload, { 
                headers: this.headers,
                httpsAgent: proxyAgent
            });
            if (response.status === 200 && response.data.code === 0) {
                this.log(`Total Point Value: ${response.data.data.point.totalPointValue}`, 'success',index);
                return { 
                    success: true, 
                    session: response.data.data.session,
                    checkin: response.data.data.checkin
                };
            } else {
                return { success: false, error: response.data.msg };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async claim(session, checkinId, proxyAgent,index) {
        const url = "https://api.codexfield.com/api/1/user/claim";
        const headers = { 
            ...this.headers, 
            "Authorization": `Bearer ${session}`
        };
        const payload = { checkinId: checkinId };

        try {
            const response = await axios.post(url, payload, { 
                headers,
                httpsAgent: proxyAgent
            });
            if (response.status === 200 && response.data.code === 0) {
                this.log(`Điểm danh hàng ngày thành công, nhận 10 Points`, 'success',index);
                return { success: true, data: response.data.data };
            } else {
                return { success: false, error: response.data.msg };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async checkTaskStatusAndClaim(session, proxyAgent,index) {
        const statusUrl = "https://api.codexfield.com/api/1/task/status";
        const claimUrl = "https://api.codexfield.com/api/1/task/claim";
        const headers = { 
            ...this.headers, 
            "Authorization": `Bearer ${session}`
        };

        try {
            const statusResponse = await axios.get(statusUrl, { 
                headers,
                httpsAgent: proxyAgent
            });
            if (statusResponse.status !== 200 || statusResponse.data.code !== 0) {
                throw new Error("Failed to get task status");
            }

            const socialTasks = statusResponse.data.data.socialTasks;
            const completedTasks = socialTasks.filter(task => task.status === 1);

            for (const task of completedTasks) {
                const payload = {
                    taskGroup: "social",
                    claimKey: task.id
                };

                const claimResponse = await axios.post(claimUrl, payload, { 
                    headers,
                    httpsAgent: proxyAgent
                });
                if (claimResponse.status === 200 && claimResponse.data.code === 0) {
                    this.log(`Làm nhiệm vụ ${task.taskType} thành công | Phần thưởng: ${task.rewardPoint} Points`, 'success',index);
                    this.log(`Total Point Value: ${claimResponse.data.data.totalPointValue}`, 'custom',index);
                } else {
                    this.log(`Không thể claim nhiệm vụ ${task.taskType}: ${claimResponse.data.msg}`, 'error',index);
                }

                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async processAccounts(data, threadIndex, threadCount) {
        // Xử lý các tài khoản cho mỗi thread
        const startIndex = threadIndex * Math.floor(data.length / threadCount);
        const endIndex = Math.min((threadIndex + 1) * Math.floor(data.length / threadCount), data.length);
    
        //console.log(`Thread ${threadIndex + 1} đang xử lý từ ${startIndex} đến ${endIndex}`);
    
        for (let i = startIndex; i < endIndex; i++) {
            const index = i;
            const initData = data[i];
            const userData = JSON.parse(decodeURIComponent(initData.split('user=')[1].split('&')[0]));
            const userId = userData.id;
            const firstName = userData.first_name;
            const proxy = this.proxies[i];
            const proxyAgent = new HttpsProxyAgent(proxy);
    
            let proxyIP = "Unknown";
            try {
                proxyIP = await this.checkProxyIP(proxy);
            } catch (error) {
                this.log(`Lỗi khi kiểm tra IP của proxy: ${error.message}`, 'error',index);
                continue;
            }
    
            //console.log(`========== Tài khoản ${i + 1} | ${firstName.green} | ip: ${proxyIP} ==========`);
    
            // Đăng nhập và xử lý nhiệm vụ
            const loginResult = await this.login(initData, proxyAgent,index);
            if (loginResult.success) {
                if (loginResult.checkin) {
                    const claimResult = await this.claim(loginResult.session, loginResult.checkin.id, proxyAgent,index);
                    if (claimResult.success) {
                        this.log(`Points: ${claimResult.data.totalPointValue}`, 'success',index);
                    } else {
                        this.log(`Không thể claim: ${claimResult.error}`, 'error',index);
                    }
                }
                const taskResult = await this.checkTaskStatusAndClaim(loginResult.session, proxyAgent,index);
                if (!taskResult.success) {
                    this.log(`Lỗi khi kiểm tra và claim nhiệm vụ: ${taskResult.error}`, 'error',index);
                }
            } else {
                this.log(`Đăng nhập không thành công! ${loginResult.error}`, 'error',index);
            }
    
            // Chờ 1 giây giữa các tác vụ
            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
    
    async main() {
        const dataFile = path.join(__dirname, 'data.txt');
        const data = fs.readFileSync(dataFile, 'utf8')
            .replace(/\r/g, '')
            .split('\n')
            .filter(Boolean);
        this.log('Tool được chia sẻ tại kênh telegram Automatin PaulKevin (https://t.me/AutomationPaulKevin)'.green);
        this.log('query_id chỉ có hạn 1 ngày, nhớ lấy lại mỗi ngày nhé'.magenta);

        console.log(`Dữ liệu có ${data.length} tài khoản.`);
    
        // Kiểm tra threadCount có giá trị hợp lý
        if (!this.threadCount || this.threadCount <= 0) {
            console.error('Thread count không hợp lệ!');
            return;
        }
    
        while (true) {
            const tasks = []; // Danh sách các công việc cần xử lý
    
            // Sử dụng threadCount để chia công việc ra các thread
            for (let i = 0; i < this.threadCount; i++) {
                tasks.push(this.processAccounts(data, i, this.threadCount));
            }
    
            console.log(`Đang bắt đầu xử lý ${this.threadCount} luồng...`);
    
            // Chạy các tác vụ song song
            await Promise.all(tasks);
    
            // Chờ trước khi lặp lại
            await this.countdown(86400);
        }
    }
}

const client = new Codex();
client.main().catch(err => {
    client.log(err.message, 'error');
    process.exit(1);
});