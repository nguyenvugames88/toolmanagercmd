function parseUrlAndGetToken(url) {
    // Tách phần hash từ URL
    const hash = url.split('#')[1];
    if (!hash) {
        throw new Error('Invalid URL: No hash found');
    }

    // Tìm phần tgWebAppData
    const params = new URLSearchParams(hash);
    const tgWebAppData = params.get('tgWebAppData');
    if (!tgWebAppData) {
        throw new Error('Invalid URL: No tgWebAppData found');
    }

    // Giải mã dữ liệu tgWebAppData
    const decodedData = decodeURIComponent(tgWebAppData);
    const userDataMatch = decodedData.match(/user=(.*?)(?:&|$)/);
    if (!userDataMatch) {
        throw new Error('Invalid tgWebAppData: No user data found');
    }

    // Giải mã thông tin người dùng
    const userData = decodeURIComponent(userDataMatch[1]);
    const userJson = JSON.parse(userData);

    // Tạo token từ thông tin người dùng
    const token = btoa(JSON.stringify({
        query_id: decodedData.match(/query_id=(.*?)(?:&|$)/)[1],
        user: userJson,
        auth_date: decodedData.match(/auth_date=(.*?)(?:&|$)/)[1],
        hash: decodedData.match(/hash=(.*?)(?:&|$)/)[1],
    }));

    return token;
}

// Ví dụ sử dụng
const url = 'https://tma.cryptorank.io/?tgWebAppStartParam=ref_5926079709_#tgWebAppData=user%3D%257B%2522id%2522%253A5926079709%252C%2522first_name%2522%253A%2522Paul%2520Kevin%2522%252C%2522last_name%2522%253A%2522%2522%252C%2522username%2522%253A%2522PaulKevin88%2522%252C%2522language_code%2522%253A%2522en%2522%252C%2522allows_write_to_pm%2522%253Atrue%257D%26chat_instance%3D-8724405961958393100%26chat_type%3Dprivate%26start_param%3Dref_5926079709_%26auth_date%3D1729448990%26hash%3D8f203cbf5eff98660bac7a9cb308012dab4fdf38d6dcc6d27ce182881676f89b&tgWebAppVersion=7.10&tgWebAppPlatform=web&tgWebAppThemeParams=%7B%22bg_color%22%3A%22%23212121%22%2C%22button_color%22%3A%22%238774e1%22%2C%22button_text_color%22%3A%22%23ffffff%22%2C%22hint_color%22%3A%22%23aaaaaa%22%2C%22link_color%22%3A%22%238774e1%22%2C%22secondary_bg_color%22%3A%22%23181818%22%2C%22text_color%22%3A%22%23ffffff%22%2C%22header_bg_color%22%3A%22%23212121%22%2C%22accent_text_color%22%3A%22%238774e1%22%2C%22section_bg_color%22%3A%22%23212121%22%2C%22section_header_text_color%22%3A%22%238774e1%22%2C%22subtitle_text_color%22%3A%22%23aaaaaa%22%2C%22destructive_text_color%22%3A%22%23ff595a%22%7D';
const token = parseUrlAndGetToken(url);
console.log(token);
